<<?php
phpinfo();
?>

<script type="text/javascript"> 
    function jsCopyusername(){ 
        var e=document.getElementById("bank-username");//对象是content 
        e.select(); //选择对象 
        document.execCommand("Copy"); //执行浏览器复制命令
       alert("已复制好，可贴粘。"); 
    } 
</script> 

<script type="text/javascript"> 
    function jsCopyaccount(){ 
        var e=document.getElementById("bank-account");//对象是content 
        e.select(); //选择对象 
        document.execCommand("Copy"); //执行浏览器复制命令
       alert("已复制好，可贴粘。"); 
    } 
</script>
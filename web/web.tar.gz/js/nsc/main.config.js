define('myConfig', function(){
	require.config({
		baseUrl: '/js/nsc',
		waitSeconds:0
	})
})
﻿
<meta content="IE=EmulateIE8" http-equiv="X-UA-Compatible" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?=$this->settings['webName']. '-官方网站'?></title>
  <link rel="stylesheet" href="/css/layui/css/layui.css"  media="all">
<link href="/css/nsc/lottery.css" rel="stylesheet" type="text/css" />
<link href='/skin/main/bl_ococ.css' rel="stylesheet" type="text/css" />
<link type="text/css" rel="stylesheet" href="/skin/js/jqueryui/jquery-ui-1.8.23.custom.css">
<script type="text/javascript" src="/skin/js/jquery-1.8.3.min.js"></script>

<script>var TIP=true;</script>
<script type="text/javascript" src="/skin/main/onload.js"></script>
<script type="text/javascript" src="/skin/main/function.js"></script>
<script type="text/javascript" src="/skin/js/jqueryui/jquery-ui-1.8.23.custom.min.js"></script>

<script type="text/javascript" src="/js/nsc/main.js"></script>

<link rel="stylesheet" href="/css/nsc/foot.css?v=1.16.11.5">

<script src="/js/nsc/zr-script.js?v=1.16.11.5" charset="utf-8"></script>
<script type="text/javascript" src="/js/nsc/soundBox.js"></script>
<script type="text/javascript" src="/js/nsc/lottery/youxi_lang_zh.js?v=1.16.11.5"></script>
<script type="text/javascript" src="/js/nsc/lottery/jquery.youxi.main.js?v=1.16.11.5"></script>
<script type="text/javascript" src="/js/nsc/lottery/jquery.youxi.selectarea.js?v=1.16.11.5"></script>
<script type="text/javascript" src="/js/nsc/lottery/jquery.youxi.trace.js?v=1.16.11.5"></script>
<script type="text/javascript" src="/skin/layer/layer.js1"></script>
<script type="text/javascript" src="/css/layui/layui.js"></script>
<!-- slidebar -->
<link href="/css/jquery.nouislider.css" rel="stylesheet">
<link href="/css/nouislider.min.css" rel="stylesheet">
<script src="/css/nouislider.min.js"></script>
<style>
	 #basic_slider{ width:120px;height:10px;}
		
	 #basic_slider .noUi-origin{
		 background:#FF632C; 
		 height: initial !important;
		 width: initial !important;
	}
	
	 #basic_slider .noUi-handle{
		width:14px;
		height:14px;
	}
 </style>
<!-- slidebar end -->

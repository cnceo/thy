﻿<table border='0' cellspacing='0' cellpadding='0' scrolling="auto">
    <?php $this->display('index/inc_data_history_get.php', 0, 30); ?>
</table>

<input type="hidden" name="playedGroup" value="<?=$this->groupId?>" />
<input type="hidden" name="playedId" value="<?=$this->played?>" />
<input type="hidden" name="type" value="<?=$this->type?>" />
<div class="dGameStatus hklhc lotteryView_sxtw" action="tzlhcSelect" length="1">
                <div class="Contentbox" id="Contentbox_0">
        <div class="sxtwBox" >
		<dl>
			<dt>
		<span>生肖</span><span style="margin-left:50px;">号码</span><span style="margin-left:111px;">赔率</span><span>金额</span>
			</dt>
		<dd>
		<span class="sGameStatusItem">鼠</span><span style="margin-left: 30px;" class="blue">10</span><span class="green">22</span><span class="green">34</span><span class="red">46</span><span style="margin-left:60px;" class="num"><?=$this->getLHCRte('RteLTTA01',$this->played)?></span>
		<span class="input"><input maxlength="5" id="CdtLTTA01" name="LTTBP" acno="鼠" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">牛</span><span style="margin-left: 30px;" class="red">09</span><span class="blue">21</span><span class="green">33</span><span class="green">45</span><span style="margin-left:60px;" class="num"><?=$this->getLHCRte('RteLTTA02',$this->played)?></span>
		<span class="input"><input maxlength="5" id="CdtLTTA02" name="LTTBP" acno="牛" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">虎</span><span style="margin-left: 30px;" class="red">08</span><span class="red">20</span><span class="blue">32</span><span class="green">44</span><span style="margin-left:60px;" class="num"><?=$this->getLHCRte('RteLTTA03',$this->played)?></span>
		<span class="input"><input maxlength="5" id="CdtLTTA03" name="LTTBP" acno="虎" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">兔</span><span style="margin-left: 30px;" class="green">07</span><span class="red">19</span><span class="red">31</span><span class="blue">43</span><span style="margin-left:60px;" class="num"><?=$this->getLHCRte('RteLTTA04',$this->played)?></span>
		<span class="input"><input maxlength="5" id="CdtLTTA04" name="LTTBP" acno="兔" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">龙</span><span style="margin-left: 30px;" class="green">06</span><span class="green">18</span><span class="red">30</span><span class="blue">42</span><span style="margin-left:60px;" class="num"><?=$this->getLHCRte('RteLTTA05',$this->played)?></span>
		<span class="input"><input maxlength="5" id="CdtLTTA05" name="LTTBP" acno="龙" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">蛇</span><span style="margin-left: 30px;" class="blue">05</span><span class="green">17</span><span class="green">29</span><span class="red">41</span><span style="margin-left:60px;" class="num"><?=$this->getLHCRte('RteLTTA06',$this->played)?></span>
		<span class="input"><input maxlength="5" id="CdtLTTA06" name="LTTBP" acno="蛇" type="text"></span>
		</dd>
		</dl>
		<dl>
			<dt>
		<span>生肖</span><span style="margin-left:50px;">号码</span><span style="margin-left:111px;">赔率</span><span>金额</span>
			</dt>
		<dd>
		<span class="sGameStatusItem">马</span><span style="margin-left: 30px;" class="blue">04</span><span class="blue">16</span><span class="green">28</span><span class="green">40</span><span style="margin-left:60px;" class="num"><?=$this->getLHCRte('RteLTTA07',$this->played)?></span>
		<span class="input"><input maxlength="5" id="CdtLTTA07" name="LTTBP" acno="马" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">羊</span><span style="margin-left: 30px;" class="red">03</span><span class="blue">15</span><span class="blue">27</span><span class="green">39</span><span style="margin-left:60px;" class="num"><?=$this->getLHCRte('RteLTTA08',$this->played)?></span>
		<span class="input"><input maxlength="5" id="CdtLTTA08" name="LTTBP" acno="羊" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">鸡</span><span style="margin-left: 30px;" class="red">01</span><span class="red">13</span><span class="blue">25</span><span class="blue">37</span><span class="green">49</span><span style="margin-left:27px;" class="num"><?=$this->getLHCRte('RteLTTA09',$this->played)?></span>
		<span class="input"><input maxlength="5" id="CdtLTTA09" name="LTTBP" acno="鸡" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">猴</span><span style="margin-left: 30px;" class="red">02</span><span class="red">14</span><span class="blue">26</span><span class="blue">38</span><span style="margin-left:60px;" class="num"><?=$this->getLHCRte('RteLTTA10',$this->played)?></span>
		<span class="input"><input maxlength="5" id="CdtLTTA10" name="LTTBP" acno="猴" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">狗</span><span style="margin-left: 30px;" class="green">12</span><span class="red">24</span><span class="red">36</span><span class="blue">48</span><span style="margin-left:60px;" class="num"><?=$this->getLHCRte('RteLTTA11',$this->played)?></span>
		<span class="input"><input maxlength="5" id="CdtLTTA11" name="LTTBP" acno="狗" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">猪</span><span style="margin-left: 30px;" class="blue">11</span><span class="green">23</span><span class="red">35</span><span class="red">47</span><span style="margin-left:60px;" class="num"><?=$this->getLHCRte('RteLTTA12',$this->played)?></span>
		<span class="input"><input maxlength="5" id="CdtLTTA12" name="LTTBP" acno="猪" type="text"></span>
		</dd>
		</dl>
		
		<div class="dGameStatus hklhc lotteryView_lhc2" action="tzlhcSelect" length="1">
                <div class="Contentbox" id="Contentbox_0">
        <div class="lhcBox2" >
		<dl>
			<dt>
		<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
			</dt>
		<dd>
		<span id="RteSPBSOED" class="sGameStatusItem">0尾</span><span class="num" style="margin-left:12px;"><?=$this->getLHCRte('RteLTTSD0',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="CdtLTTSD0" name="LTTSD" acno="0尾" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPBSOES" class="sGameStatusItem">1尾</span><span class="num" style="margin-left:12px;"><?=$this->getLHCRte('RteLTTSD1',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="CdtLTTSD1" name="LTTSD" acno="1尾" type="text"></span>
		</dd>
		</dl>
			<dl>
		<dt>
		<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
			</dt>
		<dd>
		<span id="RteSPBSOEO" class="sGameStatusItem">2尾</span><span class="num" style="margin-left:12px;"><?=$this->getLHCRte('RteLTTSD2',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="CdtLTTSD2" name="LTTSD" acno="2尾" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPBSOEE" class="sGameStatusItem">3尾</span><span class="num" style="margin-left:12px;"><?=$this->getLHCRte('RteLTTSD3',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="CdtLTTSD3" name="LTTSD" acno="3尾" type="text"></span>
		</dd>
			</dl>
			<dl>
		<dt>
		<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
			</dt>
		<dd>
		<span id="RteSPTBSOED" class="sGameStatusItem">4尾</span><span class="num" style="margin-left:12px;"><?=$this->getLHCRte('RteLTTSD4',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="CdtLTTSD4" name="LTTSD" acno="4尾" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPTBSOES" class="sGameStatusItem">5尾</span><span class="num" style="margin-left:12px;"><?=$this->getLHCRte('RteLTTSD5',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="CdtLTTSD5" name="LTTSD" acno="5尾" type="text"></span>
		</dd>
			</dl>
			<dl>
		<dt>
		<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
			</dt>
		<dd>
		<span id="RteSPTBSOEO" class="sGameStatusItem">6尾</span><span class="num" style="margin-left:12px;"><?=$this->getLHCRte('RteLTTSD6',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="CdtLTTSD6" name="LTTSD" acno="6尾" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPTBSOEE" class="sGameStatusItem">7尾</span><span class="num" style="margin-left:12px;"><?=$this->getLHCRte('RteLTTSD7',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="CdtLTTSD7" name="LTTSD" acno="7尾" type="text"></span>
		</dd>
			</dl>
			<dl>
		<dt>
		<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
			</dt>
		<dd>
		<span id="RteSPSBSD" class="sGameStatusItem">8尾</span><span class="num" style="margin-left:-3px;"><?=$this->getLHCRte('RteLTTSD8',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="CdtLTTSD8" name="LTTSD" acno="8尾" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPSBSS" class="sGameStatusItem">9尾</span><span class="num" style="margin-left:-3px;"><?=$this->getLHCRte('RteLTTSD9',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="CdtLTTSD9" name="LTTSD" acno="9尾" type="text"></span>
		</dd>
			</dl>	

    
		</div>
                 
         </div>
              </div>    
			  </div>  
			  </div>
            </div>
		
				<div class="addOrderBox" >
                <div class="addOrderLeft addOrderLeftsxtw">
                                   
                   <input type="button" class="addBtn" onclick="bringRte();" value="添加投注">
                    <div class="chooseMsg">
                        <p>总金额共 <span id="sTotalCredit">0</span> 元</p>
                    </div>
                </div>
           
            </div>

<div src="/index.php/index/zhuiHaoQs/" rel="2.000" style="display: block; width: auto; min-height: 0px; height: 230px;">
<div  style="position:relative;
font-weight: bold;
border-top: 1px solid #e6e6e6;border-bottom:1px solid #e6e6e6;
border-right: 2px solid #e6e6e6;
border-left: 2px solid #e6e6e6;
line-height: 40px;
text-align: center;
font-size: 13px;">
<select name="qh" style=" border:#000 1px solid; margin-bottom:4px; width:95px;margin-left: 24px;">
<option value="10">最近10期</option>
<option value="20">最近20期</option>
<option value="30">最近30期</option>
<option value="40">最近40期</option>
<option value="50">最近50期</option>
<option value="0">今天全部</option>
</select>
<label><input style="margin-left: 30px;" type="checkbox" checked name="zhuiHaoMode" value="1"/>中奖后停止追号</label>
</div>
<table width="100%">
	<thead class="tr-top">
		<tr>
			<td><input type="checkbox" />
			<td>期号</td>
			<td>倍数</td>
			<td>金额</td>
			<td>开奖时间</td>
		</tr>
	</thead>
	<tbody  class="tr-cont">
	</tbody>
</table>
</div>